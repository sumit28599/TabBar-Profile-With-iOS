//
//  Constants.swift
//  TabbarApp
//
//  Created by SADDAM KHAN on 13/03/23.
//

import Foundation

let userStandard = UserDefaults.standard

enum UserDefaultKey: String {

    //User Into Key
    case isAlreadyLogin = "isAlreadyLogin"
    case userId = "userId"
    case firstName = "firstName"
    case lastName = "lastName"
    case emailId = "emailId"
    case contactNumber = "contactNumber"
    case profileImage = "profileImage"

    //Setting Related Key
    case lastNameKey = "lastNameKey"
    case contactKey = "contactKey"
    case imageDisplay = "imageDisplay"

    //Register User Count Key
    case registerUserCount = "registerUserCount"
    
    //Food Info Key
    case foodId = "foodId"
    case foodName = "foodName"
    case foodImage = "foodImage"
    
}



