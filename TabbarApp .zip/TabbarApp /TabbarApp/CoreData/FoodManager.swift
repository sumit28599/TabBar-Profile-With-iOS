//
//  FoodManager.swift
//  TabbarApp
//
//  Created by iPHTech 15 on 24/03/23.
//

import Foundation
import CoreData

class FoodManager {
    
    static let shared = FoodManager()
    
    private init() {}
    
    //Step 1 - setting value in core data
    func createFood(foodDetails: Food) {
        
        let food = FoodList(context: CoreDataManager.shared.context)
        let foodCount = userStandard.integer(forKey: UserDefaultKey.registerUserCount.rawValue)
        
        food.foodId = "\(foodCount)"
        
        food.foodName = foodDetails.foodName
        food.foodImage = foodDetails.foodImage
        food.foodId = foodDetails.foodId
        
        //MARK: saving data into core data
        CoreDataManager.shared.saveContext()
    }
    
    //Step 2 - fetching value from core data
    //MARK: 2.fetch User List from Core data (Read)
    //first method - using concept of array
    func getFoodList() -> [FoodList]{
        
        //creation of empty array of type class User
        var foodList = [FoodList]()
        do {
            //while fetching data from core data we can get a runtime error becoz it might be possible that core data is empty.
            let foods = try CoreDataManager.shared.context.fetch(FoodList.fetchRequest())
            
            foodList = foods //foodList array getting filled  with foods available in core data if any.
        }
        catch let error {
            print(error)
        }
        return foodList
    }
    
    
    
    //MARK: Update User Details.
  //  func updateUser(foodId: String, foodName: String = "",  foodImageName: String = "") -> (errorCode: Int, errorMessage: String) {
    func updateFood(foodDetails:Food) -> (errorCode: Int, errorMessage: String) {
        
        let fetchRequest = NSFetchRequest<FoodList>(entityName: FoodList.description())
        let predicate = NSPredicate(format: "foodId==%@", foodDetails.foodId as CVarArg)
        fetchRequest.predicate = predicate

        do {
            if let foods = try CoreDataManager.shared.context.fetch(fetchRequest) as? [FoodList] {
                if foods.count == 1 {
                    let food = foods.first!
                    food.foodName = foodDetails.foodName
                    food.foodImage = foodDetails.foodImage
                    CoreDataManager.shared.saveContext()
                    return (errorCode: 200, errorMessage: "Profile data successfully updated")
                }
                return (errorCode: 201, errorMessage: "Food not exist")
            }
        }
        catch {
            print("Error occured during fetch students: \(error)")
        }
        return (errorCode: 201, errorMessage: "Food not exist")
    }
}
