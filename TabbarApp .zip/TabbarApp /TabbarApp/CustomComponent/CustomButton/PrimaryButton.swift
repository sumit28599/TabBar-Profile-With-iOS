//
//  PrimaryButton.swift
//  TabbarApp
//
//  Created by iPHTech 29 on 14/03/23.
//

import UIKit

class PrimaryButton: UIButton {

    private enum Constants {
        static let buttonBackgroundColor = UIColor.black
        static let buttonTextColor = UIColor.white
        static let buttonCornerRadius = 8.0
    }

    override init(frame: CGRect){
        super.init(frame: frame)
    }

    required init?(coder aDecoder: NSCoder) {
       super.init(coder: aDecoder)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        setup()
    }

    func setup() {
        
        self.clipsToBounds = true
        self.backgroundColor = Constants.buttonBackgroundColor
        self.setTitleColor(Constants.buttonTextColor, for: .normal)
        self.layer.cornerRadius = Constants.buttonCornerRadius
    }
    

}
