//
//  UtilityFunctions.swift
//  TabbarApp
//
//  Created by SADDAM KHAN on 16/03/23.
//

import Foundation


class UtilityFunctions {
    
    static let sharedInstance = UtilityFunctions()
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    func validatePhoneNumber(validationText:String) -> Bool{
        let  ALLOWED_PHONE_NUMBER_DIGITS = 10//11
        let phoneNumberRegEx = "[0-9]{\(ALLOWED_PHONE_NUMBER_DIGITS)}"
        let phoneNumberTest = NSPredicate(format:"SELF MATCHES %@", phoneNumberRegEx)
        return phoneNumberTest.evaluate(with: validationText)
    }
    
}
