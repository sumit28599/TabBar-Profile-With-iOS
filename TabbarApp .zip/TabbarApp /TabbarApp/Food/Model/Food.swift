//
//  Food.swift
//  TabbarApp
//
//  Created by iPHTech40 on 01/03/23.
//

import Foundation

struct Food {
    
    let foodName: String
    let foodId: String
    let foodImage: String

    static func defaultFoodList() -> [Food] {

        var foodList = [Food]()
        foodList.append(Food(foodName: "Apple",foodId: "1",foodImage: "house"))
        foodList.append(Food(foodName: "Grape",foodId: "2",foodImage: "house"))
        foodList.append(Food(foodName: "Guava",foodId: "3",foodImage: "house"))
        foodList.append(Food(foodName: "Mango",foodId: "4",foodImage: "house"))
        foodList.append(Food(foodName: "Papaya",foodId: "5",foodImage: "house"))

        return foodList
    }
}
