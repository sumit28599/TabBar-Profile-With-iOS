//
//  MyCollectionViewCell.swift
//  TabbarApp
//
//  Created by iPHTech40 on 01/03/23.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myImageView: UIImageView!
    @IBOutlet weak var foodNameLabel: UILabel!
    
    
}
