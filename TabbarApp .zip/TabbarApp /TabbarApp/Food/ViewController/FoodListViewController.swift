//
//  FriendListViewController.swift
//  TabbarApp
//
//  Created by Saddam Khan on 27/02/23.
//

import UIKit

class FoodListViewController: UIViewController {
    
    //MARK: IBOutlet
    @IBOutlet weak var myCollectionView: UICollectionView!
    
    //MARK: Variable
    var foodListArray = [Food]()
    var contain: String?
    
    
    //MARK: Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //MARK: Read Check by printing on console
        //Step 3 - checking if values are set or not
     
        let foodList = FoodManager.shared.getFoodList()
        for food in foodList {
            let foodData = Food(foodName: food.foodName ?? "Default Name",
                                foodId: food.foodId ?? "12345",
                                foodImage: food.foodImage ?? "noImage")
            foodListArray.append(foodData)
        }
    }
    
    
    
    
    
    
    //MARK: nextPageButtonAction
    @IBAction func nextPageButtonAction(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ImageShowCollectionViewController") as! ImageShowCollectionViewController
        //  vc.imageReceived.image = UIImage(named: foodListArray[presentIndex.row].foodName)
        vc.delegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

//MARK: UICollectionViewDelegate & UICollectionViewDataSource
extension FoodListViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        foodListArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = myCollectionView.dequeueReusableCell(withReuseIdentifier: "MyCollectionViewCell", for: indexPath) as! MyCollectionViewCell
        
        
        if foodListArray[indexPath.row].foodImage == "noImage" || foodListArray[indexPath.row].foodImage == ""{
            // no image found
            cell.myImageView.image = UIImage(systemName: "person")
        }
        else {
            // image found
            // get image from url
            if let imageUrl = URL(string: "file://\(foodListArray[indexPath.row].foodImage)") {
                //url exist
                do {
                    let imageData = try Data(contentsOf: imageUrl,options: [])
                    if let imageToShow = UIImage(data: imageData) {
                        cell.myImageView.image = imageToShow
                    }
                }catch let error {
                    print(error)
                }
                
            }
            //show it to image view
        }
        cell.foodNameLabel.text = foodListArray[indexPath.row].foodName
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if let vc = storyboard?.instantiateViewController(identifier: "ImageShowCollectionViewController") as? ImageShowCollectionViewController {
            vc.imageReceived =  UIImage(named: foodListArray[indexPath.row].foodName)!
            vc.labelValue = foodListArray[indexPath.row].foodName
            vc.foodData = foodListArray[indexPath.row]
            vc.presentIndex = indexPath.row //contains index of selected cell
            vc.delegate = self
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

extension FoodListViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {

        let width = (collectionView.frame.size.width-41.0)/3.0
        return CGSize(width: width, height: width)
    }
    
}


extension FoodListViewController: ImageShowCollectionViewControllerDelegate {

    func addOrUpdateFood(food: Food, index: Int) {
        if index == -1 {
            foodListArray.append(food)
        }
        else {
            foodListArray[index] = food
        }
        myCollectionView.reloadData()
    }
    
    func deleteFood(index: Int) {
        foodListArray.remove(at: index)
        myCollectionView.reloadData()
    }
}
