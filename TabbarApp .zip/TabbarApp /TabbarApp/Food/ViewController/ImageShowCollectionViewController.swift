//
//  ImageShowCollectionViewController.swift
//  TabbarApp
//
//  Created by iPHTech40 on 02/03/23.
//

import UIKit

protocol ImageShowCollectionViewControllerDelegate: AnyObject {
    func addOrUpdateFood(food: Food, index: Int)
    func deleteFood(index: Int)
}

class ImageShowCollectionViewController: UIViewController, UIGestureRecognizerDelegate  {
    
    //MARK: IBOutlet
    @IBOutlet var imageShow: UIImageView!
    @IBOutlet weak var foodTextField: UITextField!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var deleteBarButton: UIBarButtonItem!
    
    
    var foodData: Food?
    weak var delegate: ImageShowCollectionViewControllerDelegate?
    var presentIndex: Int?
    var imagePicker = UIImagePickerController()
    
    
    //MARK: object
    var imageReceived = UIImage()
    var labelValue = ""
    
    
    //MARK: Hide Tab Bar Icon
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }
    
    
    //MARK: Life Cycle Method
    override func viewDidLoad() {
        super.viewDidLoad()
        imageShow.image = imageReceived
        foodTextField.text = labelValue
        setupUI()
        setData()
        
        addTapGesture()
    }
    
    func addTapGesture() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(didTapImageView))
        imageShow.isUserInteractionEnabled = true
        //imageShow.tag =
        imageShow.addGestureRecognizer(tapGestureRecognizer)
    }
    
    @objc func didTapImageView(){
        //open Gallary and choose Image
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            imagePicker.allowsEditing = false
            
            present(imagePicker, animated: true, completion: nil)
        }
    }
    private func setupUI() {
        
        updateButton.layer.cornerRadius = 12.0
        updateButton.layer.borderWidth = 0.0
        updateButton.layer.shadowOffset = CGSize(width: 0.0,height: 5)
        updateButton.layer.shadowRadius = 5
        updateButton.layer.shadowOpacity = 0.3
        updateButton.layer.masksToBounds = false
        
        if foodData == nil {
            updateButton.setTitle("Add", for: .normal)
            deleteBarButton.isHidden = true
        }
        else {
            updateButton.setTitle("Update", for: .normal)
            deleteBarButton.isHidden = false
        }
    }
    
    private func setData() {
        
        foodTextField.text = userStandard.string(forKey: UserDefaultKey.foodName.rawValue)
        
//        if profileImageData != nil {
//            profileImage.image = profileImageData
//        }
    }
    
    
    @IBAction func updateButtonAction(_ sender: Any) {
        
        
        let paths = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
        print(paths[0])
        
        //save to database
        var foodId: String = ""
        if foodData == nil {
            foodId = getFoodId()
        }
        else {
            foodId =  foodData?.foodId ?? ""
        }
       
        let foodName =  self.foodTextField.text ?? ""
        let finalPath = saveImageDocumentDirectory(foodName: foodName, foodId: foodId)
        let foodDetail = Food(foodName: foodName, foodId: foodId, foodImage:finalPath)
        
        if foodData == nil {
            //create
            FoodManager.shared.createFood(foodDetails: foodDetail)
        }
        else{
            //update
            FoodManager.shared.updateFood(foodDetails: foodDetail)
        }
            userStandard.set(foodName, forKey: UserDefaultKey.foodName.rawValue)
//
//            showAlert(message: updateFoodResult.errorMessage)
    }
    
    func getFoodImagePath(foodName: String, foodId: String) -> String {
        let doc =  getDocumentsDirectory()
        let appendPath = doc.appendingPathComponent("\(foodName)_\(foodId).jpeg")
        return appendPath.path
    }
    
    func saveImageDocumentDirectory(foodName: String, foodId: String) -> String{
       
        let doc = getDocumentsDirectory()
        let appendPath = doc.appendingPathComponent("\(foodName)_\(foodId).jpeg")
        let finalpath = appendPath.path
        let imageData = imageShow.image?.jpegData(compressionQuality: 0.5)
        do {
            try imageData?.write(to: appendPath)
        }catch let error {
            print(error)
        }
        return finalpath
    }
    
    func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentsDirectory = paths[0]
        return documentsDirectory
    }
    //generate a 6 digit random number
    func getFoodId() -> String{
        var res = 0
        for i in 1 ... 6 {
            let randomInt = Int.random(in: 0..<10)
            res = res*10 + randomInt
        }
       return "\(res)"
    }
    
    
    @IBAction func deleteButtonTapped(_ sender: Any) {
        
        Alert.shared.showAlert(vc: self, title: "Refresh", message: "Are you sure you want to delete the item?", yesActionTitle: "Yes", noActionTitle: "No") { [weak self] value in
            guard let self = self else { return }
            if value == "Yes" {
                //print("Handle Ok logic here")
                self.delegate?.deleteFood(index: self.presentIndex ?? -1)
                self.navigationController?.popViewController(animated: true)
            }
            else {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
   func showAlert(message: String) {

       Alert.shared.showAlert(vc: self, title: "Alert", isNeedToShowCancel: false, message: message, yesActionTitle: "Okay") { _ in }
  }
}


extension ImageShowCollectionViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        DispatchQueue.main.async {
            if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
                self.imageShow.image = image
                self.imageShow.contentMode = .scaleToFill
            }
        }
        
    }
}
