//
//  Friends.swift
//  TabbarApp
//
//  Created by Saddam Khan on 01/03/23.
//

import Foundation

struct Friend {
    
    let firstName: String
    let lastName: String
    let contact: String
    
    static func defaultFriendList() -> [Friend] {
        
        var friendList = [Friend]()
        friendList.append(Friend(firstName: "Ajay", lastName: "Kumar", contact: "7894561234"))
        friendList.append(Friend(firstName: "Faisal", lastName: "Khan", contact: "9994561234"))
        friendList.append(Friend(firstName: "Madhukar", lastName: "Panday", contact: "7894001234"))
        friendList.append(Friend(firstName: "Faizan", lastName: "Khan", contact: "7894009934"))
        friendList.append(Friend(firstName: "Sumit", lastName: "Jaiswal", contact: "7888001234"))
        return friendList
    }
}
