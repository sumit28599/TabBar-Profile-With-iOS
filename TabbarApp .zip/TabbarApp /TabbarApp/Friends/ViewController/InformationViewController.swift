//
//  InformationViewController.swift
//  TabbarApp
//
//  Created by iPHTech40 on 28/02/23.
//

import UIKit

protocol InformationViewControllerDelegate: AnyObject {
    
    func addOrUpdateFriend(friend: Friend, index: Int)
    func deleteFriend(index: Int)
}

class InformationViewController: UIViewController {
    
    //MARK: IBOutlets
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var contactTextField: UITextField!
    @IBOutlet weak var deleteBarButton: UIBarButtonItem!
    @IBOutlet weak var submitButton: UIButton!
    
    
    
    //MARK: Constants
    var friendData: Friend?
    weak var delegate: InformationViewControllerDelegate?
    var currentIndex: Int?
    
    //MARK: Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setData()
    }
    
    private func setupUI() {
        
        submitButton.layer.cornerRadius = 12.0
        submitButton.layer.borderWidth = 0.0
        submitButton.layer.shadowOffset = CGSize(width: 0.0,height: 5)
        submitButton.layer.shadowRadius = 5
        submitButton.layer.shadowOpacity = 0.3
        submitButton.layer.masksToBounds = false
        
        if friendData == nil {
            submitButton.setTitle("Add", for: .normal)
            deleteBarButton.isHidden = true
        }
        else {
            submitButton.setTitle("Update", for: .normal)
            deleteBarButton.isHidden = false
        }
    }
    
    private func setData() {
        
        firstNameTextField.text = "\(friendData?.firstName ?? "")"
        lastNameTextField.text = "\(friendData?.lastName ?? "")"
        contactTextField.text = "\(friendData?.contact ?? "")"
    }
    
    //MARK: submitAction
    @IBAction func submitAction(_ sender: UIButton) {
        
        if firstNameTextField.text == "" || lastNameTextField.text == "" || contactTextField.text == "" {
            navigationController?.popViewController(animated: true)
            return
        }
        
        delegate?.addOrUpdateFriend(friend: Friend(firstName: firstNameTextField.text ?? "", lastName: lastNameTextField.text ?? "", contact: contactTextField.text ?? ""), index: currentIndex ?? -1)
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func deleteAction(_ sender: UIBarButtonItem) {
        
        Alert.shared.showAlert(vc: self, title: "Refresh", message: "Are you sure you want to delete the item?", yesActionTitle: "Yes") { [weak self] value in
            guard let self = self else { return }
            if value == "Yes" {
                //print("Handle Ok logic here")
                self.delegate?.deleteFriend(index: self.currentIndex ?? -1)
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
}
