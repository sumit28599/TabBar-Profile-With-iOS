//
//  File.swift
//  TabbarApp
//
//  Created by iPHTech40 on 06/03/23.
//

import Foundation
//this model is not used for handling core data. The model that is generated automatically is used for core data handling.
struct Profile {
    
    let firstName: String
    let lastName: String
    let contact: String
    let rollNo: String
    
    static func defaultProfileData() -> [Profile] {
        
        var profileData = [Profile]()
        profileData.append(Profile(firstName: "Ajay", lastName: "kumar", contact: "56566245", rollNo: "9473839257"))
        return profileData
    }
}
