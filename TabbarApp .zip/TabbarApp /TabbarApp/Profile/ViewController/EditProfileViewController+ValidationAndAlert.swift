//
//  EditProfileViewController+ValidationAndAlert.swift
//  TabbarApp
//
//  Created by SADDAM KHAN on 24/03/23.
//

import UIKit

extension EditProfileViewController {
    
    //MARK: Validation for update user data.
    func checkValidation(firstName: String, lastName: String, email: String, contact: String) -> Bool {
        
        if firstName == "" {
            showAlert(message: "Please enter first name")
        }
        else if lastName == "" {
            showAlert(message: "Please enter last name")
        }
        else if email == "" {
            showAlert(message: "Please enter email")
        }
        else if !UtilityFunctions.sharedInstance.isValidEmail(email) {
            showAlert(message: "Please enter valid email")
        }
        else if contact == "" {
            showAlert(message: "Please enter contact")
        }
        else if !UtilityFunctions.sharedInstance.validatePhoneNumber(validationText: contact) {
            showAlert(message: "Please enter valid contact")
        }
        else {
            return true
        }
        return false
    }
    
    //MARK: Alert.
    func showAlert(message: String) {
        
        Alert.shared.showAlert(vc: self, title: "Alert", isNeedToShowCancel: false, message: message, yesActionTitle: "Okay") { _ in }
    }
}
