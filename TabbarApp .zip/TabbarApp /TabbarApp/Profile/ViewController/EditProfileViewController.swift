//
//  EditProfileViewController.swift
//  TabbarApp
//
//  Created by iPHTech40 on 06/03/23.
//
import UIKit

protocol ProfileDetailViewControllerDelegate: AnyObject {
    func updateProfile(profile: Profile)
    //func deleteFriend(index: Int)
}



class EditProfileViewController: UIViewController {
    
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var contactTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    
    
   // var profileData: Profile?
    var profileImageData: UIImage?
    weak var delegate: ProfileDetailViewControllerDelegate?
    var currentIndex: Int?
    let imagePicker = UIImagePickerController()

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setData()
        setupUI()
    }
    private func setupUI(){
        profileImage?.layer.cornerRadius = (profileImage?.frame.size.width ?? 0.0) / 2
        profileImage?.clipsToBounds = true
        profileImage?.layer.borderWidth = 3.0
        profileImage?.layer.borderColor = UIColor.white.cgColor
        }
    
    
    private func setData() {
        
        firstNameTextField.text = userStandard.string(forKey: UserDefaultKey.firstName.rawValue)
        lastNameTextField.text = userStandard.string(forKey: UserDefaultKey.lastName.rawValue)
        emailTextField.text = userStandard.string(forKey: UserDefaultKey.emailId.rawValue)
        contactTextField.text = userStandard.string(forKey: UserDefaultKey.contactNumber.rawValue)
        if profileImageData != nil {
            profileImage.image = profileImageData
        }
    }

    @IBAction func profileCameraAction(_ sender: Any) {
        
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { [weak self] _ in
            guard let self = self else {
                return
            }
            self.cameraTapped()

        }))
        
        actionSheet.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { [weak self] _ in
            guard let self = self else {
                return
            }
            self.galleryTapped()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(actionSheet, animated: true, completion: nil)
        
    }
    
    @IBAction func saveAction(_ sender: Any) {
        
        let userId = userStandard.string(forKey: UserDefaultKey.userId.rawValue)
        
        let firstName = firstNameTextField.text ?? ""
        let lastName = lastNameTextField.text ?? ""
        let email = emailTextField.text ?? ""
        let contact = contactTextField.text ?? ""
        
        if checkValidation(firstName: firstName, lastName: lastName, email: email, contact: contact) {
            let updateUserResult = UserManager.shared.updateUser(userId: userId ?? "", firstName: firstName, lastName: lastName, email: email, contact: contact)
            userStandard.set(firstName, forKey: UserDefaultKey.firstName.rawValue)
            userStandard.set(lastName, forKey: UserDefaultKey.lastName.rawValue)
            userStandard.set(email, forKey: UserDefaultKey.emailId.rawValue)
            userStandard.set(contact, forKey: UserDefaultKey.contactNumber.rawValue)
            showAlert(message: updateUserResult.errorMessage)
        }
    }
    
    //MARK: Gallery Action.
    func galleryTapped() {
        
        self.imagePicker.allowsEditing = true
        self.imagePicker.sourceType = .photoLibrary
        self.imagePicker.delegate = self
        self.present(self.imagePicker, animated: true, completion: nil)
    }
    
    func cameraTapped() {
        
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            
            self.imagePicker.allowsEditing = true
            self.imagePicker.sourceType = .camera
            self.imagePicker.delegate = self
            
            self.present(self.imagePicker, animated: true, completion: nil)
        }
        else {
            print("Camera is not avaliable")
        }
    }
}


extension EditProfileViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        picker.dismiss(animated: true, completion: nil)
        
        var imageDataValue = UIImage()
        if let img = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            imageDataValue = img
        }
        else if let img = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            imageDataValue = img
        }
        profileImage.image = imageDataValue

        let folderName = "Users"
        let userId = userStandard.string(forKey: UserDefaultKey.userId.rawValue) ?? ""
        let fileName = "\(userId).jpg"

        let fileManager = FileManager.default
        let documentsFolder = try! fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        let folderURL = documentsFolder.appendingPathComponent(folderName)
        let fileURL = folderURL.appendingPathComponent(fileName)
        let folderExists = (try? folderURL.checkResourceIsReachable()) ?? false
        do {
            if !folderExists {
                try fileManager.createDirectory(at: folderURL, withIntermediateDirectories: false)
            }
            //, !FileManager.default.fileExists(atPath: fileURL.path)
            if let data = imageDataValue.jpegData(compressionQuality: 0.5) {
                // writes the image data to disk
                try data.write(to: fileURL)
                //Save record in core data
                let userId = userStandard.string(forKey: UserDefaultKey.userId.rawValue)
                let updateUserResult = UserManager.shared.updateUser(userId: userId ?? "", profileImageName: fileName)
                //Save in userDefault
                userStandard.set(fileName, forKey: UserDefaultKey.profileImage.rawValue)
                showAlert(message: updateUserResult.errorMessage)
            }
        } catch {
            print("error:", error)
        }

    }
    
    
    
      
}

