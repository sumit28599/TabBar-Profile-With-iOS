//
//  FriendListViewController.swift
//  TabbarApp
//
//  Created by Saddam Khan on 27/02/23.
//

import UIKit

class SettingViewController: UIViewController {
    
    @IBOutlet weak var lastNameSwitch: UISwitch!
    @IBOutlet weak var contactSwitch: UISwitch!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
        
    }
    
    
    private func setupUI() {
        
        let isNameOn = userStandard.bool(forKey: UserDefaultKey.lastNameKey.rawValue)
        lastNameSwitch.isOn = isNameOn
        
        let isContactOn = userStandard.bool(forKey: UserDefaultKey.contactKey.rawValue)
        contactSwitch.isOn = isContactOn
        
    }
    
    //MARK: Switch Actions
    @IBAction func lastNameSwitchAction(_ sender: UISwitch) {
        
        userStandard.set(sender.isOn, forKey: UserDefaultKey.lastNameKey.rawValue)
        
    }
    
    @IBAction func contactSwitchAction(_ sender: UISwitch) {
        
        userStandard.set(sender.isOn, forKey: UserDefaultKey.contactKey.rawValue)
        
        //        userStandard.removeObject(forKey: UserDefaultKey.imageDisplay.rawValue)
        
        //Remove All
        let domain = Bundle.main.bundleIdentifier!
        UserDefaults.standard.removePersistentDomain(forName: domain)
    }
    
    @IBAction func deleteAccountAction(_ sender: Any) {
        
        Alert.shared.showAlert(vc: self, title: "Alert", isNeedToShowCancel: true, message: "Are you sure want to delete this user ?", yesActionTitle: "Yes", noActionTitle: "No") { [weak self] value in
            guard let self = self else { return }
            if value == "Yes" {
                
                let userId = userStandard.string(forKey: UserDefaultKey.userId.rawValue)
                let deleteUserResult = UserManager.shared.deleteUser(userId: userId ?? "")
                if deleteUserResult.errorCode == 200 {

                    userStandard.removeObject(forKey: UserDefaultKey.isAlreadyLogin.rawValue)
                    userStandard.removeObject(forKey: UserDefaultKey.userId.rawValue)
                    userStandard.removeObject(forKey: UserDefaultKey.firstName.rawValue)
                    userStandard.removeObject(forKey: UserDefaultKey.lastName.rawValue)
                    userStandard.removeObject(forKey: UserDefaultKey.emailId.rawValue)
                    userStandard.removeObject(forKey: UserDefaultKey.contactNumber.rawValue)
                    userStandard.removeObject(forKey: UserDefaultKey.profileImage.rawValue)
                    let userCount = userStandard.integer(forKey: UserDefaultKey.registerUserCount.rawValue) - 1
                    userStandard.set(userCount, forKey: UserDefaultKey.registerUserCount.rawValue)

                    let introViewController = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "IntroViewController") as! IntroViewController
                    let navigationController = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "RootNavigationController") as! UINavigationController
                    navigationController.viewControllers = [introViewController]
                    self.view.window?.rootViewController = navigationController
                    self.view.window?.makeKeyAndVisible()
                }
            }
        }

    }

    @IBAction func signoutAction(_ sender: Any) {
        
        Alert.shared.showAlert(vc: self, title: "Alert", isNeedToShowCancel: true, message: "Are you sure want to logout ?", yesActionTitle: "Yes", noActionTitle: "No") { [weak self] value in
            guard let self = self else { return }
            if value == "Yes" {
                
                //Set User Value empty
        //        userStandard.set("", forKey: UserDefaultKey.userId.rawValue)
        //        userStandard.set("", forKey: UserDefaultKey.firstName.rawValue)
        //        userStandard.set("", forKey: UserDefaultKey.lastName.rawValue)
        //        userStandard.set("", forKey: UserDefaultKey.emailId.rawValue)
        //        userStandard.set("", forKey: UserDefaultKey.contactNumber.rawValue)
        //        userStandard.set("", forKey: UserDefaultKey.profileImage.rawValue)
        //        userStandard.set("", forKey: UserDefaultKey.isAlreadyLogin.rawValue)
                //OR
        //        userStandard.removeObject(forKey: UserDefaultKey.userId.rawValue)
        //        userStandard.removeObject(forKey: UserDefaultKey.firstName.rawValue)
        //        userStandard.removeObject(forKey: UserDefaultKey.lastName.rawValue)
        //        userStandard.removeObject(forKey: UserDefaultKey.emailId.rawValue)
        //        userStandard.removeObject(forKey: UserDefaultKey.profileImage.rawValue)
        //        userStandard.removeObject(forKey: UserDefaultKey.isAlreadyLogin.rawValue)

                userStandard.set("", forKey: UserDefaultKey.isAlreadyLogin.rawValue)

                let loginViewController = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
                let introViewController = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "IntroViewController") as! IntroViewController

                let navigationController = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "RootNavigationController") as! UINavigationController
                navigationController.viewControllers = [introViewController]
                self.view.window?.rootViewController = navigationController
                self.view.window?.makeKeyAndVisible()
            }
        }

    }
    
}
