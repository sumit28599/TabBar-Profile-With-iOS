//
//  IntroViewController.swift
//  TabbarApp
//
//  Created by iPHTech 29 on 14/03/23.
//

import UIKit

class IntroViewController: UIViewController {
    
    
    @IBOutlet weak var messageLabel: UILabel!


    func sumOfTwoNumber(num1: Int, num2: Int) -> Int {
        return num1+num2
    }
    
    let sumOfTwoNumberClosure: (Int,Int) -> Int = { (num1, num2) in
        return num1+num2
    }

    var sumOfTwoNumberClosure2: ((Int,Int) -> Int)? = nil

    var loadResponseAfterAPICall: ((String) -> Void)? = nil



    override func viewDidLoad() {
        super.viewDidLoad()

        let userList = UserManager.shared.getUserList2ndMethod()
        for user in userList {
            print(user.userId)
            print(user.firstName)
            print(user.lastName)
            print(user.emailId)
            print(user.contactNumber)
            print(user.password)
            print(user.profileImage)
        }

        let sum1 = sumOfTwoNumber(num1: 10, num2: 30)
//        print(sum1)

        //MARK: Closure
        let sum2 = sumOfTwoNumberClosure(10, 20)
//        print(sum2)

        sumOfTwoNumberClosure2 = { (num1, num2) in
            return num1+num2
        }

        loadResponseAfterAPICall = { [weak self] message in
//            print(message)
//            print(message)
//            print(message)
//            print(message)
//            print(message)
//            self?.messageLabel.text = message
//            guard let self = self else { return }
//            self.messageLabel.text = message
        }
        
    }
    

    //MARK: Signup Tap Action
    @IBAction func signupTapAction(_ sender: UIButton) {

        let vc = storyboard?.instantiateViewController(withIdentifier: "SignupViewController") as! SignupViewController
        navigationController?.pushViewController(vc, animated: true)
        
        
        //MARK: Using Closure
//        print(sumOfTwoNumberClosure2!(20,30))

    }
    
    //MARK: Login Tap Action
    @IBAction func loginTapAction(_ sender: UIButton) {

        
        let vc = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        navigationController?.pushViewController(vc, animated: true)

        //MARK: Using Closure
        loadResponseAfterAPICall!("API call success")
    }
}
