//
//  LoginViewController.swift
//  TabbarApp
//
//  Created by iPHTech 29 on 14/03/23.
//

import UIKit

class LoginViewController: UIViewController {

    //MARK: @IBOutlet
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!


    //MARK: Variables
    var isComingFromSignup = false
    

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()

    }
    
    //MARK: SetupUI
    private func setupUI() {
        
        emailTextField.text = "saddam@gmail.com"
        passwordTextField.text = "1234"
    }

    //MARK: Signup Tap Action
    @IBAction func signupTapAction(_ sender: UIButton) {
        
        if isComingFromSignup {
            navigationController?.popViewController(animated: true)
        }
        else {
            let vc = storyboard?.instantiateViewController(withIdentifier: "SignupViewController") as! SignupViewController
            vc.isComingFromLogin = true
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    //MARK: Login Tap Action
    @IBAction func loginTapAction(_ sender: UIButton) {
        
        let email = emailTextField.text ?? ""
        let password = passwordTextField.text ?? ""
        
        if checkValidation(email: email, password: password) {
            let loginUserResult = UserManager.shared.checkUserAbleToLogin(emailId: email, password: password)
            if loginUserResult.errorCode == 200 {
                userStandard.set(loginUserResult.userDetails?.userId, forKey: UserDefaultKey.userId.rawValue)
                userStandard.set(loginUserResult.userDetails?.firstName, forKey: UserDefaultKey.firstName.rawValue)
                userStandard.set(loginUserResult.userDetails?.lastName, forKey: UserDefaultKey.lastName.rawValue)
                userStandard.set(loginUserResult.userDetails?.emailId, forKey: UserDefaultKey.emailId.rawValue)
                userStandard.set(loginUserResult.userDetails?.contactNumber, forKey: UserDefaultKey.contactNumber.rawValue)
                userStandard.set(loginUserResult.userDetails?.profileImage, forKey: UserDefaultKey.profileImage.rawValue)
                userStandard.set("1", forKey: UserDefaultKey.isAlreadyLogin.rawValue)
                
                let tabBarViewController = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "TabBarViewController") as! TabBarViewController
                //        self.navigationController?.pushViewController(myTaBarController, animated: true)
                self.view.window?.rootViewController = tabBarViewController
                self.view.window?.makeKeyAndVisible()


            }
            else {
                showAlert(message: loginUserResult.errorMessage)
            }
        }
    }

    //MARK: Check validation
    private func checkValidation(email: String, password: String) -> Bool {
        
        if email == "" {
            showAlert(message: "Please enter email")
        }
        else if !UtilityFunctions.sharedInstance.isValidEmail(email) {
            showAlert(message: "Please enter valid email")
        }
        else if password == "" {
            showAlert(message: "Please enter password")
        }
        else {
            return true
        }
        return false
    }

    private func showAlert(message: String) {

        Alert.shared.showAlert(vc: self, title: "Alert", isNeedToShowCancel: false, message: message, yesActionTitle: "Okay") { _ in }
        
        
        let userValue = User()
    }
    
}
