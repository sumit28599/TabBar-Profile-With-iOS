//
//  SignupViewController.swift
//  TabbarApp
//
//  Created by iPHTech 29 on 14/03/23.
//

import UIKit

class SignupViewController: UIViewController {

    //MARK: @IBOutlet
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var contactTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!


    //MARK: Variables
    var isComingFromLogin = false

    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
    }
    
    //MARK: SetupUI
    private func setupUI() {
        
        firstNameTextField.text = "Saddam"
        lastNameTextField.text = "Khan"
        emailTextField.text = "saddam@gmail.com"
        contactTextField.text = "1234567890"
        passwordTextField.text = "1234"
        confirmPasswordTextField.text = "1234"
    }
    
    //MARK: Signup Tap Action
    @IBAction func signupTapAction(_ sender: UIButton) {

        let firstName = firstNameTextField.text ?? ""
        let lastName = lastNameTextField.text ?? ""
        let email = emailTextField.text ?? ""
        let contact = contactTextField.text ?? ""
        let password = passwordTextField.text ?? ""
        let confirmPassword = confirmPasswordTextField.text ?? ""

        if checkValidation(firstName: firstName, lastName: lastName, email: email, contact: contact, password: password, confirmPassword: confirmPassword) {
            let createUserResult = UserManager.shared.createUser(firstName: firstName, lastName: lastName, email: email, contact: contact, password: password)
            if createUserResult.errorCode == 200 {
//                showAlert(message: "\(createUserResult.errorMessage)\nDo you want to login")
                Alert.shared.showAlert(vc: self, title: "Alert", isNeedToShowCancel: true, message: "\(createUserResult.errorMessage).\nDo you want to login ?", yesActionTitle: "Yes", noActionTitle: "No") { [weak self] value in
                    guard let self = self else { return }
                    if value == "Yes" {
                        self.goToLogin()
                        
                        
                    }
                }

            }
            else {
                showAlert(message: createUserResult.errorMessage)
            }
        }
    }

    //MARK: Check validation
    private func checkValidation(firstName: String, lastName: String, email: String, contact: String, password: String, confirmPassword: String) -> Bool {

        if firstName == "" {
            showAlert(message: "Please enter first name")
        }
        else if lastName == "" {
            showAlert(message: "Please enter last name")
        }
        else if email == "" {
            showAlert(message: "Please enter email")
        }
        else if !UtilityFunctions.sharedInstance.isValidEmail(email) {
            showAlert(message: "Please enter valid email")
        }
        else if contact == "" {
            showAlert(message: "Please enter contact")
        }
        else if !UtilityFunctions.sharedInstance.validatePhoneNumber(validationText: contact) {
            showAlert(message: "Please enter valid contact")
        }
        else if password == "" {
            showAlert(message: "Please enter password")
        }
        else if confirmPassword == "" {
            showAlert(message: "Please enter confirm password")
        }
        else if password != confirmPassword {
            showAlert(message: "Password doesn't match")
        }
        else {
            return true
        }
        return false
    }

    //MARK: Login Tap Action
    @IBAction func loginTapAction(_ sender: UIButton) {

        goToLogin()
    }
    
    private func goToLogin() {
        
        if isComingFromLogin {
            navigationController?.popViewController(animated: true)
        }
        else {
            let vc = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
            vc.isComingFromSignup = true
            navigationController?.pushViewController(vc, animated: true)
        }

    }
    
    private func showAlert(message: String) {

        Alert.shared.showAlert(vc: self, title: "Alert", isNeedToShowCancel: false, message: message, yesActionTitle: "Okay") { _ in }
    }
    
}
